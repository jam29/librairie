package org.librairie;

import org.librairie.controller.EcrivainController;
import org.librairie.model.entity.Ecrivain;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        EcrivainController ec = new EcrivainController();
        ec.afficheEcrivains();
    }
}