package org.librairie.controller;

import org.librairie.model.entity.Ecrivain;
import org.librairie.model.service.EcrivainService;
import org.librairie.view.EcrivainView;

import java.util.List;

public class EcrivainController {
    private EcrivainService ecrivainService = new EcrivainService();
    private EcrivainView ecrivainView = new EcrivainView();
    public void afficheEcrivains() {
        List<Ecrivain> ecrivains = ecrivainService.getEcrivains();
        ecrivainView.AfficheEcrivains(ecrivains);
    }
}
