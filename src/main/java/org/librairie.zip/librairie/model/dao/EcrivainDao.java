package org.librairie.model.dao;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.librairie.HibernateUtil;
import org.librairie.model.entity.Ecrivain;

import java.util.List;

public class EcrivainDao {
    // echange objet->Databe et Database vers Objet
    public List<Ecrivain> getEcrivains() {
        // je récupère la session Hibernate qui permet de persister les données.
        Session session = HibernateUtil.getSessionFactory().openSession();
        Query<Ecrivain> query = session.createQuery("from Ecrivain",Ecrivain.class);
        List<Ecrivain> ecrivains = query.getResultList();
        return ecrivains;
    }
}
