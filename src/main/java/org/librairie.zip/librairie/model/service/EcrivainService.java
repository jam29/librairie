package org.librairie.model.service;

import org.librairie.model.dao.EcrivainDao;

import java.util.List;

public class EcrivainService {
   // partie service
    private EcrivainDao ecrivainDao = new EcrivainDao();
    public List getEcrivains() {
        List ecrivains = ecrivainDao.getEcrivains() ;
        return ecrivains ;
    }
}
